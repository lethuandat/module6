package com.codegym.service;

import com.codegym.model.ClassStudent;

import java.util.List;

public interface IClassStudentService {
    List<ClassStudent> findAll();
}
